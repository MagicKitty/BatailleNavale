package game;

public class BattleshipGame {
	@SuppressWarnings("unused")
	private DAO dao;
	@SuppressWarnings("unused")
	private AbstractGame ag;
	
	public void newGame(String a, String b, String c) {

	}

	public void loadGame() {
		
	}

	public void saveGame() {

	}
}
