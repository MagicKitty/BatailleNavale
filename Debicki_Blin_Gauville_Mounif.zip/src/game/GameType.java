package game;

public enum GameType {
	STANDARD,
	ADVANCED
}
