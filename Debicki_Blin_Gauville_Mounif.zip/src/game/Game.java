package game;

public class Game {
	public Game() {
		
	}
}