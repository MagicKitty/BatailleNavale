package controller;

public interface ButtonController {
	void handleButton(Object s);
}
