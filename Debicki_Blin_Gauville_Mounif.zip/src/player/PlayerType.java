package player;

public enum PlayerType {
	HUMAN,
	COMPUTER
}
