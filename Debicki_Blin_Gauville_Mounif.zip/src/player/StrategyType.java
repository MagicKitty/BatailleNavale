package player;

public enum StrategyType {
	CROSS,
	RANDOM,
	PATH
}
