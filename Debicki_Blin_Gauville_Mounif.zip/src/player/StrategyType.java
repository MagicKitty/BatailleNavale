package player;

public enum StrategyType {
	CROSS,
	RANDOM
}
