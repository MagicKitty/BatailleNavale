package main;

public enum GameStatus {
	START,
	NEW_LOAD,
	PERIOD,
	SHOT,
	ALGORITHM,
	GRID,
	INGAME
}
