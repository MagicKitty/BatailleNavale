package ship;

public interface IBehaviorDefensive {
	public double getDefense();
}
