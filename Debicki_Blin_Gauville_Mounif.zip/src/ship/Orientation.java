package ship;

public enum Orientation {
	HORIZONTAL,
	VERTICAL
}
