package ship;

public interface IBehaviorOffensive {
	public double getAttack();
}
