package period;

public enum Period {
	MODERN,
	FUTURE,
	RENAISSANCE
}
