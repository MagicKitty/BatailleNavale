# BatailleNavale

## commande de build :
### ant build

## commande de lancement :
### ant Launcher

## commande de tests :
### ant GridTests
### ant ShipCellTests
### ant SeaCellTests